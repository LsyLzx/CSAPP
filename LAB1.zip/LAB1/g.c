#include<stdio.h> 

double fibb[10000005];

int main()
{
	int n;
	fibb[2]=1;//�ݹ�߽����� 
	scanf("%d",&n);
	for(int i=3;i<=n;i++)
	{
		fibb[i]= 1.0/(1+fibb[i-1]);
	} 
	printf("%.8lf\n",fibb[n]);

	return 0;
}
