#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

long long fibb[10005];

int main()
{
	fibb[1] = 1;
	fibb[2] = 1;

	long n;
	scanf("%d", &n);
	for (int i = 3; i <= n; i++)
	{
		fibb[i] = fibb[i - 1] + fibb[i - 2];
	}

	printf("%.8lf", fibb[n - 1] * 1.0 / fibb[n]);
	return 0;
}
