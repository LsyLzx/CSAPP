#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>

long  f(int n)
{
	if (n == 1 || n == 2)return 1;
	return f(n - 1) + f(n - 2);
}
int main()
{
	long n;
	scanf("%ld", &n);

	double g = 1.0 * f(n - 1) / f(n);
	printf("%.8lf\n", g);
	
	return 0;
}
