#include<stdio.h>
int main()
{
    int n = 0;
    int* p = &n;
    printf("sizeof(char)=%ld\n", sizeof(char));//1 
    printf("sizeof(short)=%ld\n", sizeof(short));//2
    printf("sizeof(int)=%ld\n", sizeof(int));//4
    printf("sizeof(long)=%ld\n", sizeof(long));//4
    printf("sizeof(long long)=%ld\n", sizeof(long long));//8
    printf("sizeof(float)=%ld\n", sizeof(float));//4
    printf("sizeof(double)=%ld\n", sizeof(double));//8
    printf("sizeof(long double)=%ld\n", sizeof(long double));//8
    printf("sizeof(&n)=%ld\n", sizeof(p));
}
