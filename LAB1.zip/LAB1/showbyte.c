#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main() {

	int flen = 0;
	char *buf;
	FILE *fp = NULL;

	fp = fopen("hello.c", "r");
	if (fp == NULL)
	{
        printf("There is something wrong !");
		return 0;
	}
	else
	{
		fseek(fp, 0, SEEK_END);

		flen = ftell(fp);
		rewind(fp);

		buf = (char*)malloc(flen+1);

		for(int i= 0; i <=flen; i++)
			buf[i] = 0;

		int k = fread(buf, 1, flen, fp);


		fclose(fp);
	}
	int len = strlen(buf);


	int f = 0,e = 0;
	for(int i = 0; i < len; i++)
    {
		if(i % 16 == 0 && i != 0 && e== 0)
		{
			printf("\n");
			if(f == 0)
                i -= 16;
			f= !f;
		}
		if (!f)
		{
			if(buf[i] == ' ')
                printf("SP\t");
			else if(buf[i] == '\n')
                printf("\\n\t");
			else if(buf[i] == '\t')
                printf("\\t\t");
			else printf("%c\t", buf[i]);
		}
		else
		{
			if(buf[i] == ' ')
                printf("%d\t", ' ');
			else if(buf[i] == '\n')
                printf("%d\t", '\n');
			else if(buf[i] == '\t')
                printf("%d\t", '\t');
			else printf("%x\t", buf[i]);
		}
		if(i + 1 == len && !e)
		{
			printf("\n");
			i -= (len % 16);
			f = !f;
			e = 1;
		}
	}


	free(buf);
	return 0;
}
